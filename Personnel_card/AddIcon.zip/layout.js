var layout = {
	'pages':
	[
		{
			'pageName': "Incident Category",
			'isDashboard': true,
			'dashElems': [
				{
					'imgSrc': 'personnel_damage.jpg',
					'buttonLabel': 'SELECT',
					'miniTitle': 'Personnel',
				},
				{
					'imgSrc': 'cargo_damage.png',
					'buttonLabel': 'SELECT',
					'miniTitle': 'Cargo/Machinery damage'
				}
			]
		},
		{
			'pageName': "Personnel",
			'categories': 
				[
					{
						'categoryBox': true,
						'questions': [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
					}
				]
		},
		{
			'pageName': "Cargo/Machinery damage",
			'categories': 
				[
					{
						'categoryBox': true,
						'questions': [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
					}
				]
		}
	],
	"validations": {
		0 : 
			{
				'minLength': 2,
				'maxLength': 50
			},
		1: 
			{
				'minLength': 2,
				'maxLength': 150
			},
		4: 
			{
				'minLength': 2,
				'maxLength': 150
			}
	},
	'autoPopulate': 
	{
		'6': {
			'type': 'name',
			'editable': false
		},
		'7': {
			'type': 'phone',
			'editable': false
		}
	},
	'optional': [5]
}